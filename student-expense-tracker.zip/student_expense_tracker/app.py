from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os
from datetime import date, datetime

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, 'expenses.db')
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret-key-for-production')

CATEGORIES = ['Food', 'Travel', 'Education', 'Shopping', 'Bills', 'Health', 'Entertainment', 'Other']


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    with get_db() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            monthly_budget REAL NOT NULL DEFAULT 5000,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            amount REAL NOT NULL CHECK(amount > 0),
            category TEXT NOT NULL,
            expense_date TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        ''')


def current_user():
    if 'user_id' not in session:
        return None
    with get_db() as db:
        return db.execute('SELECT id, username, monthly_budget FROM users WHERE id=?', (session['user_id'],)).fetchone()


def login_required():
    if 'user_id' not in session:
        flash('Please log in to continue.', 'info')
        return False
    return True


@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        budget_raw = request.form.get('monthly_budget', '5000')
        try:
            budget = float(budget_raw)
            if budget <= 0: raise ValueError
        except ValueError:
            flash('Monthly budget must be a number greater than zero.', 'error')
            return render_template('register.html')
        if len(username) < 3 or len(username) > 30:
            flash('Username must contain 3–30 characters.', 'error')
        elif len(password) < 6:
            flash('Password must contain at least 6 characters.', 'error')
        else:
            try:
                with get_db() as db:
                    cur = db.execute('INSERT INTO users(username, password_hash, monthly_budget) VALUES (?, ?, ?)',
                                     (username, generate_password_hash(password), budget))
                    session['user_id'] = cur.lastrowid
                flash('Account created successfully. Welcome!', 'success')
                return redirect(url_for('dashboard'))
            except sqlite3.IntegrityError:
                flash('That username is already taken. Please choose another.', 'error')
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        with get_db() as db:
            user = db.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session.clear()
            session['user_id'] = user['id']
            flash('You are logged in.', 'success')
            return redirect(url_for('dashboard'))
        flash('Incorrect username or password.', 'error')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


def month_stats(user_id, month=None):
    month = month or date.today().strftime('%Y-%m')
    with get_db() as db:
        rows = db.execute('''SELECT * FROM expenses WHERE user_id=? AND substr(expense_date,1,7)=?
                             ORDER BY expense_date DESC, id DESC''', (user_id, month)).fetchall()
        total = db.execute('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND substr(expense_date,1,7)=?',
                           (user_id, month)).fetchone()[0]
        by_category = db.execute('''SELECT category, SUM(amount) AS total FROM expenses
                                    WHERE user_id=? AND substr(expense_date,1,7)=?
                                    GROUP BY category ORDER BY total DESC''', (user_id, month)).fetchall()
    return rows, float(total), by_category


@app.route('/dashboard')
def dashboard():
    if not login_required(): return redirect(url_for('login'))
    user = current_user()
    selected_month = request.args.get('month', date.today().strftime('%Y-%m'))
    try: datetime.strptime(selected_month, '%Y-%m')
    except ValueError: selected_month = date.today().strftime('%Y-%m')
    expenses, total, categories = month_stats(user['id'], selected_month)
    remaining = float(user['monthly_budget']) - total
    category_labels = [r['category'] for r in categories]
    category_values = [round(float(r['total']), 2) for r in categories]
    with get_db() as db:
        all_time = db.execute('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=?', (user['id'],)).fetchone()[0]
        count = db.execute('SELECT COUNT(*) FROM expenses WHERE user_id=? AND substr(expense_date,1,7)=?', (user['id'], selected_month)).fetchone()[0]
    return render_template('dashboard.html', user=user, expenses=expenses, total=total, remaining=remaining,
                           categories=categories, category_labels=category_labels, category_values=category_values,
                           selected_month=selected_month, all_time=float(all_time), count=count,
                           budget_percent=min(100, round(total / user['monthly_budget'] * 100)) if user['monthly_budget'] else 0,
                           today=date.today().isoformat(), category_options=CATEGORIES)


@app.route('/expenses/add', methods=['GET', 'POST'])
def add_expense():
    if not login_required(): return redirect(url_for('login'))
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '')
        expense_date = request.form.get('expense_date', '')
        notes = request.form.get('notes', '').strip()[:300]
        try:
            amount = float(request.form.get('amount', ''))
            datetime.strptime(expense_date, '%Y-%m-%d')
            if amount <= 0 or amount > 100000000: raise ValueError
        except ValueError:
            flash('Enter a valid date and an amount greater than zero.', 'error')
            return render_template('expense_form.html', mode='Add', expense=None, categories=CATEGORIES, today=date.today().isoformat())
        if not title or len(title) > 80 or category not in CATEGORIES:
            flash('Please enter a title and choose a valid category.', 'error')
        else:
            with get_db() as db:
                db.execute('INSERT INTO expenses(user_id,title,amount,category,expense_date,notes) VALUES (?,?,?,?,?,?)',
                           (session['user_id'], title, amount, category, expense_date, notes))
            flash('Expense added successfully.', 'success')
            return redirect(url_for('dashboard'))
    return render_template('expense_form.html', mode='Add', expense=None, categories=CATEGORIES, today=date.today().isoformat())


@app.route('/expenses/<int:expense_id>/edit', methods=['GET', 'POST'])
def edit_expense(expense_id):
    if not login_required(): return redirect(url_for('login'))
    with get_db() as db:
        expense = db.execute('SELECT * FROM expenses WHERE id=? AND user_id=?', (expense_id, session['user_id'])).fetchone()
    if not expense:
        flash('Expense not found.', 'error')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '')
        expense_date = request.form.get('expense_date', '')
        notes = request.form.get('notes', '').strip()[:300]
        try:
            amount = float(request.form.get('amount', ''))
            datetime.strptime(expense_date, '%Y-%m-%d')
            if amount <= 0 or amount > 100000000: raise ValueError
        except ValueError:
            flash('Enter a valid date and amount.', 'error')
            return render_template('expense_form.html', mode='Edit', expense=expense, categories=CATEGORIES, today=date.today().isoformat())
        if not title or len(title) > 80 or category not in CATEGORIES:
            flash('Please enter a title and choose a valid category.', 'error')
        else:
            with get_db() as db:
                db.execute('UPDATE expenses SET title=?,amount=?,category=?,expense_date=?,notes=? WHERE id=? AND user_id=?',
                           (title, amount, category, expense_date, notes, expense_id, session['user_id']))
            flash('Expense updated.', 'success')
            return redirect(url_for('dashboard'))
    return render_template('expense_form.html', mode='Edit', expense=expense, categories=CATEGORIES, today=date.today().isoformat())


@app.route('/expenses/<int:expense_id>/delete', methods=['POST'])
def delete_expense(expense_id):
    if not login_required(): return redirect(url_for('login'))
    with get_db() as db:
        cur = db.execute('DELETE FROM expenses WHERE id=? AND user_id=?', (expense_id, session['user_id']))
    flash('Expense deleted.' if cur.rowcount else 'Expense not found.', 'success' if cur.rowcount else 'error')
    return redirect(url_for('dashboard'))


@app.route('/settings', methods=['GET', 'POST'])
def settings():
    if not login_required(): return redirect(url_for('login'))
    user = current_user()
    if request.method == 'POST':
        try:
            budget = float(request.form.get('monthly_budget', ''))
            if budget <= 0 or budget > 100000000: raise ValueError
            with get_db() as db:
                db.execute('UPDATE users SET monthly_budget=? WHERE id=?', (budget, user['id']))
            flash('Monthly budget updated.', 'success')
            return redirect(url_for('settings'))
        except ValueError:
            flash('Enter a valid budget greater than zero.', 'error')
    return render_template('settings.html', user=user)


@app.errorhandler(404)
def not_found(_error):
    return render_template('404.html'), 404


init_db()
if __name__ == '__main__':
    app.run(debug=True)
