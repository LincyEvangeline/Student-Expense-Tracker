# Student Expense Tracker

A beginner-friendly but portfolio-ready expense tracking web app built with **Python, Flask, SQLite, HTML and CSS**. Students can record spending, review monthly totals, set a budget and see category-wise breakdowns.

## Features

- Account registration and login with hashed passwords
- Personal dashboard with monthly spending, remaining budget and all-time total
- Add, edit and delete expenses
- Expense categories, dates and optional notes
- Monthly filter and category breakdown chart
- Monthly budget settings and budget progress bar
- SQLite database created automatically
- Responsive layout for desktop and mobile
- Server-side validation and user-specific expense access

## Requirements

- Python 3.10 or newer
- pip
- A web browser

## Run on Windows

1. Download and extract the project ZIP.
2. Open the extracted `student_expense_tracker` folder.
3. Click the folder address bar in File Explorer, type `cmd`, and press Enter.
4. Create a virtual environment:

   ```bat
   py -m venv .venv
   ```

5. Activate it:

   ```bat
   .venv\Scripts\activate
   ```

6. Install dependencies:

   ```bat
   py -m pip install -r requirements.txt
   ```

7. Start the app:

   ```bat
   py app.py
   ```

8. Open `http://127.0.0.1:5000` in your browser and create an account.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000`.

## GitHub upload instructions

1. Create a new GitHub repository, for example `student-expense-tracker`.
2. Extract this ZIP and open a terminal in the project folder.
3. Run these commands (replace the URL with your own repository URL):

   ```bash
   git init
   git add .
   git commit -m "Build Student Expense Tracker with Flask"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/student-expense-tracker.git
   git push -u origin main
   ```

4. Refresh your GitHub repository page. The source code and README should appear. If Git asks you to sign in, follow GitHub's authentication prompt.

You can also upload files through GitHub's website using **Add file → Upload files**, but Git is easier for future updates.

## Project structure

```text
student_expense_tracker/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── expense_form.html
│   ├── settings.html
│   └── 404.html
└── static/
    └── style.css
```

The `expenses.db` file is generated automatically the first time the app runs and is intentionally excluded from GitHub. Do not use Flask's built-in development server as a public production server. For a deployed version, set a strong random `SECRET_KEY` environment variable and use a production WSGI server.

## Suggested future improvements

- CSV export for expenses
- Search and category filters
- Recurring expense reminders
- Downloadable monthly reports
- Optional charts using a charting library

## License

For learning and portfolio use. You may adapt the project and add your own features.
